﻿using ManagerCFA.Models;
using Microsoft.AspNetCore.Mvc;

namespace ManagerCFA.Controllers
{
    public class ManagerController : Controller
    {
        public ManagerDbContext context;

        public ManagerController(ManagerDbContext _context)
        {
            context = _context;

        }

        // this is the homePage 
        public IActionResult Index()
        {
            var Managers = context.Managers.ToList();
            return View(Managers);
        }


        // showing details to create data 
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // actual creating data in the table 
        [HttpPost]
        public IActionResult Create(Manager m)
        {
            context.Managers.Add(m);
            context.SaveChanges();
            return RedirectToAction("Index");

        }

        // showing previous data before editing 

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Manager manager = context.Managers.Find(id);
            return View(manager);
        }

        // editing the data 
        [HttpPost]
        public IActionResult Edit(Manager m)
        {
            Manager manager = context.Managers.Find(m.ManagerId);

            manager.ManagerId = m.ManagerId;
            manager.Name = m.Name;
            manager.Email = m.Email;
            manager.Contact = m.Contact;
            context.Managers.Update(manager);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        // showing all the details inside table
        [HttpGet]
        public IActionResult Details(int id)
        {
            Manager manager = context.Managers.Find(id);
            return View(manager);
        }

        // showing daata and warning before deleting data 
        [HttpGet]
        public IActionResult Delete(int id)
        {
            Manager manager = context.Managers.Find(id);
            return View(manager);
        }

        // actual deleting data 
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            Manager manager = context.Managers.Find(id);
            context.Managers.Remove(manager);
            context.SaveChanges(true);
            return RedirectToAction("Index");
        }


    }
}
