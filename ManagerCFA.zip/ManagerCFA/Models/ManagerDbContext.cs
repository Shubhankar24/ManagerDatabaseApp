﻿using Microsoft.EntityFrameworkCore;

namespace ManagerCFA.Models
{
    public class ManagerDbContext: DbContext
    {
        public ManagerDbContext(DbContextOptions<ManagerDbContext> options) : base(options) { }

        public DbSet<Manager> Managers { get; set; }


    }
}
