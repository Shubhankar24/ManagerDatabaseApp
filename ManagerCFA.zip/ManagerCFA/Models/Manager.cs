﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace ManagerCFA.Models
{
    public class Manager
    {
        // id, name, email, contact

        [Key] // ---> identifies as primary key 
        public int ManagerId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email id is Manadatory!")]
        public string Email { get; set; }

        [Required]
        public string Contact { get; set; }
    }
}
